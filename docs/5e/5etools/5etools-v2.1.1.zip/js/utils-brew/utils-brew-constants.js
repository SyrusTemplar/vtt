export const SOURCE_UNKNOWN_FULL = "(Unknown)";
export const SOURCE_UNKNOWN_ABBREVIATION = "(UNK)";
