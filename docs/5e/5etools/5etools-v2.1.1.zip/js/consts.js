export const SITE_STYLE__CLASSIC = "classic";
export const SITE_STYLE__ONE = "one";

export const SITE_STYLE_DISPLAY = {
	[SITE_STYLE__CLASSIC]: "Classic (2014)",
	[SITE_STYLE__ONE]: "Modern (2024)",
};
