import {VetoolsConfig} from "./utils-config/utils-config-config.js";
import {ConfigUi} from "./utils-config/utils-config-ui.js";

globalThis.VetoolsConfig = VetoolsConfig;
globalThis.ConfigUi = ConfigUi;
