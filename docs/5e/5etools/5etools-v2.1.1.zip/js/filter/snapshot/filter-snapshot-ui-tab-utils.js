export class FilterSnapshotUiTabUtils {
	static getStgControls () { return ee`<div class="w-100 ve-flex-col"></div>`; }
	static getStgNoRows () { return ee`<div class="h-100 min-h-0 w-100 ve-overflow-y-scroll ve-flex-vh-center"></div>`; }
}
