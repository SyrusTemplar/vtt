export class EncounterBuilderConsts {
	static TIERS = ["easy", "medium", "hard", "deadly", "absurd"];
}
