v2.1.1

- Added "Gear" display to 2024-style Bestiary statblocks
- (Brew) Added "Partnered" filter to Get Homebrew
- (Brew) Fixed dynamic generation of 2024-compatible subclasses
- (Brew) Fixed race "reprintedAs" being applied to subraces
- (Fixed typos/added tags)
