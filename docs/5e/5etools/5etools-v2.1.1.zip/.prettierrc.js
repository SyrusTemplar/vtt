/** @type {import("prettier").Config} */
const config = {
	printWidth: 999,
};

export default config;
